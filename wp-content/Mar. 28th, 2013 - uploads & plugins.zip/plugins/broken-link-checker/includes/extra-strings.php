<?php
_x("Basic HTTP", "module name", "broken-link-checker");
_x("Blogroll items", "module name", "broken-link-checker");
_x("Comments", "module name", "broken-link-checker");
_x("Custom fields", "module name", "broken-link-checker");
_x("Embedded DailyMotion videos", "module name", "broken-link-checker");
_x("Embedded GoogleVideo videos", "module name", "broken-link-checker");
_x("Embedded Megavideo videos", "module name", "broken-link-checker");
_x("Embedded Vimeo videos", "module name", "broken-link-checker");
_x("Embedded YouTube videos", "module name", "broken-link-checker");
_x("Embedded YouTube videos (old embed code)", "module name", "broken-link-checker");
_x("FileServe API", "module name", "broken-link-checker");
_x("HTML images", "module name", "broken-link-checker");
_x("HTML links", "module name", "broken-link-checker");
_x("MediaFire API", "module name", "broken-link-checker");
_x("MegaUpload API", "module name", "broken-link-checker");
_x("Plaintext URLs", "module name", "broken-link-checker");
_x("RapidShare API", "module name", "broken-link-checker");
_x("YouTube API", "module name", "broken-link-checker");
_x("Posts", "module name", "broken-link-checker");
_x("Pages", "module name", "broken-link-checker");
?>